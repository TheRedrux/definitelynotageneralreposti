# Unnamed Badges

These badges are not identified by name in the show, but the artist rendered them anyways.

I have taken the liberty of giving each of them appropriate names.

Visit here for more information bout where they come from:

https://bulbapedia.bulbagarden.net/wiki/Badge#Gallery_of_unidentified_Badges

- MajorVictory (8/14/2020)